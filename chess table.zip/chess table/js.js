let i = 0;
let j = 0;
let test = "";
for(i = 0; i<8; i++){
  test += `<tr>` 
  // if(i % 2 == 0){
  //     test.style.backgroundcolor = 'white'
  //   }
  //   else{
  //     test.style.backgroundcolor = 'black'
  //   }
  for(j = 0; j<8; j++){
    test += `<td>  </td>`
    // if(j % 2 == 0){
    //   test.style.backgroundcolor = 'black'
    // }
    // else{
    //   test.style.backgroundcolor = 'white'
    // }
  }
 test += `</tr>`
}

document.getElementById("show").innerHTML = test;